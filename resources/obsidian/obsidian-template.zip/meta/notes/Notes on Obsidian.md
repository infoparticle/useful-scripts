

### Templates
```
{{DATE: YYYY}}  #space after DATE: is important!
```


### Install Sheets plugin to get fancy tables, for now not needed



```sheet
{
    "classes": {
        "vertical": {
            "transform": "rotate(180deg)",
            "writing-mode": "vertical-lr",
            "text-align": "left",
            "vertical-align": "center",
            "padding": "10px"
        },
        "teal": {
            "background-color": "#f3ffa2",
            "color": "black"
        }
    }
}
---
| Criteria       | Quick Implementation ~ .vertical | Solves Problem ~.vertical| **Low Cost**  ~.vertical| **Low Risk** ~.vertical|
|:-------------- |:------------------------:|:------------------:|:------------:|:------------:|
| **Solution A** |            +  ~.teal           |         <       |      +       |      S       |
| **Solution B** |            +             |         S          |      +       |      -       |
| **Solution C** |            S             |         ^         |      o     |      S       |
| **Solution D** |            S             |         -          |      S       |      +       |

```
