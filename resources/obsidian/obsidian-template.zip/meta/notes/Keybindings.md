
- `Ctrl + Q` run quick add