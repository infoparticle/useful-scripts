

### list all pages with given tag

```
---
target_tag: "#Subjects/Economics/Assets"
---


dataview
LIST
WHERE contains(file.tags, this.target_tag)
SORT file.name ASC
```